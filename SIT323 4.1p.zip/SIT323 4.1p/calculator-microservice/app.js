const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

app.post('/add', (req, res) => {
    const { num1, num2 } = req.body;

    if (!isValidNumbers(num1, num2)) {
        return res.status(400).json({ error: 'Invalid input parameters' });
    }

    const result = num1 + num2;
    res.json({ result });
});

app.post('/subtract', (req, res) => {
    const { num1, num2 } = req.body;

    if (!isValidNumbers(num1, num2)) {
        return res.status(400).json({ error: 'Invalid input parameters' });
    }

    const result = num1 - num2;
    res.json({ result });
});

app.post('/multiply', (req, res) => {
    const { num1, num2 } = req.body;

    if (!isValidNumbers(num1, num2)) {
        return res.status(400).json({ error: 'Invalid input parameters' });
    }

    const result = num1 * num2;
    res.json({ result });
});

app.post('/divide', (req, res) => {
    const { num1, num2 } = req.body;

    if (!isValidNumbers(num1, num2)) {
        return res.status(400).json({ error: 'Invalid input parameters' });
    }

    if (num2 === 0) {
        return res.status(400).json({ error: 'Division by zero is not allowed' });
    }

    const result = num1 / num2;
    res.json({ result });
});

function isValidNumbers(num1, num2) {
    return !isNaN(num1) && !isNaN(num2);
}

app.listen(port, () => {
    console.log(`Calculator microservice listening at http://localhost:${port}`);
});
